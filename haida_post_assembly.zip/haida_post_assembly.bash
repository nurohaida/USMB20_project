#!/bin/bash

#this script takes Spades assembled contig file ('contigs.fasta')  and list out filtered contigs with filter_kmer_coverage >5 and min length >=200
#the listed files were the subjected to second perl script "fastagrep.pl" that will fetch the passed criteria contigs list.

grep '>' contigs.fasta |sed -e 's/_/ /g'| sort -nrk 6 |awk '$6>5.0 && $4>=200 {print $0}'|sed -e 's/ /_/g'|sed -e 's/>//g'>contigs.fasta.txt
perl fastagrep.pl -f contigs.fasta.txt contigs.fasta > finalcontigs.fasta