#!/usr/bin/perl

use strict;
use warnings;


#this wrapper script(haida_post_assembly.pl) calls the bash script "haida_post_assembly.bash" that takes Spades assembled contig file ('contigs.fasta')  and list out filtered contigs with filter_kmer_coverage >5 and min length >=200
#the listed files were then subjected to second perl script "fastagrep.pl" that will fetch the passed criteria contigs list.

system("sh", "haida_post_assembly.bash")